import React from "react";
import OnClickView from "./OnClickView/OnClickView";
import SingleContent from "./SingleContent/SingleContent";

const BadgeInside =(gener ,setGener)=>{
    
}
export default BadgeInside;