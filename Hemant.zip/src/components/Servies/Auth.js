export let options = {
    method: "GET",
    headers: {
      accept: "application/json",
      Authorization:
        "Bearer eyJhbGciOiJIUzI1NiJ9.eyJhdWQiOiIxZjE1NTk1MGU1ZjFhZjZiYmNlMWViYWI5YWRiMGZjOSIsInN1YiI6IjY0NDY3NjA5YTA2ZWZlM2Q2NGE0ZjFlZiIsInNjb3BlcyI6WyJhcGlfcmVhZCJdLCJ2ZXJzaW9uIjoxfQ.djsqQkka2gUZNmK9l4Px96S1X95sxudKyCZWew_K_pM",
    },
  };